# 🌙 Green Moon Savings — Deployment Guide
## Stack: Node.js + Express · MongoDB Atlas · Vercel

---

## Step 1 — Set up MongoDB Atlas (free database)

1. Go to **https://mongodb.com/atlas** → click **Try Free**
2. Create an account, then click **Create a Free Cluster** (M0 tier = free forever)
3. Choose any region close to Uganda (e.g. AWS Frankfurt)
4. In **Database Access** → Add a new database user:
   - Username: `greenmoon`
   - Password: generate a strong one and **save it**
   - Role: `Read and write to any database`
5. In **Network Access** → Click **Add IP Address** → **Allow Access from Anywhere** (0.0.0.0/0)
6. Click **Connect** on your cluster → **Drivers** → copy the connection string, e.g.:
   ```
   mongodb+srv://greenmoon:<password>@cluster0.abcde.mongodb.net/?retryWrites=true&w=majority
   ```
7. Replace `<password>` with your actual password and add the DB name:
   ```
   mongodb+srv://greenmoon:YourPassword@cluster0.abcde.mongodb.net/greenmoon?retryWrites=true&w=majority
   ```
   Save this — it's your `MONGODB_URI`

---

## Step 2 — Push code to GitHub

1. Go to **https://github.com** → **New Repository** → name it `green-moon-savings`
2. Copy the files from this project to your computer
3. Open terminal in the project folder:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/green-moon-savings.git
   git push -u origin main
   ```

---

## Step 3 — Deploy to Vercel (free hosting)

1. Go to **https://vercel.com** → Sign up with GitHub
2. Click **Add New Project** → Import your `green-moon-savings` repo
3. Vercel auto-detects the settings. Click **Environment Variables** and add:

   | Name | Value |
   |------|-------|
   | `MONGODB_URI` | `mongodb+srv://greenmoon:...` (from Step 1) |
   | `JWT_SECRET` | Any long random string, e.g. `gm2024xK9pLmN3qR7vWsY` |

4. Click **Deploy** — wait ~1 minute
5. ✅ Your app is live at `https://green-moon-savings.vercel.app`

---

## Step 4 — First Login & Setup

1. Open your app URL on your phone
2. **Admin login**: username `admin`, password `admin123`
3. ⚠️ **Immediately change the admin password** in More → Settings → Change Password
4. Start adding members!

---

## 📱 Install on Android
- Open in Chrome → tap the **⋮ menu** → **Add to Home Screen**

## 📱 Install on iPhone
- Open in Safari → tap the **Share button (□↑)** → **Add to Home Screen**

---

## Project Structure
```
green-moon/
├── api/
│   └── index.js          ← Express backend (all API routes)
├── public/
│   └── index.html        ← Mobile PWA frontend
├── package.json
├── vercel.json           ← Routing config
├── .env.example          ← Template for env variables
└── DEPLOY.md             ← This file
```

## API Endpoints
| Method | Path | Description |
|--------|------|-------------|
| POST | /api/auth/login | Login |
| POST | /api/auth/register | Register |
| PUT | /api/auth/password | Change password |
| GET | /api/data | Load all data (polled every 5s) |
| POST | /api/members | Add member |
| PUT | /api/members/:id | Edit member |
| POST | /api/contributions | Record contribution |
| POST | /api/loans | Issue loan |
| POST | /api/loans/:id/repay | Record repayment |
| POST | /api/loan-requests | Submit request (member) |
| PUT | /api/loan-requests/:id/approve | Approve request |
| PUT | /api/loan-requests/:id/reject | Reject request |
| PUT | /api/users/:id/approve | Approve registration |
| DELETE | /api/users/:id | Reject registration |
| GET/PUT | /api/settings | Group settings |
