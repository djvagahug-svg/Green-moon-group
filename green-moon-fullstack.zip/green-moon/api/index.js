// ================================================================
//  GREEN MOON SAVINGS — Backend API
//  Express + Mongoose, deployed as Vercel Serverless Function
// ================================================================
require('dotenv').config();
const express   = require('express');
const mongoose  = require('mongoose');
const bcrypt    = require('bcryptjs');
const jwt       = require('jsonwebtoken');
const cors      = require('cors');

const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-in-production';
const today = () => new Date().toISOString().slice(0, 10);

// ── MONGOOSE CONNECTION (cached for serverless) ──────────────────
let _cached = global._mg || (global._mg = { conn: null, promise: null });
async function connectDB() {
  if (_cached.conn) return _cached.conn;
  if (!_cached.promise) {
    _cached.promise = mongoose.connect(process.env.MONGODB_URI, { bufferCommands: false, maxPoolSize: 10 });
  }
  _cached.conn = await _cached.promise;
  return _cached.conn;
}

// ── SCHEMAS ──────────────────────────────────────────────────────
const { Schema } = mongoose;
const UserSchema = new Schema({ username:{type:String,unique:true,required:true,trim:true}, password:{type:String,required:true}, role:{type:String,enum:['admin','member'],default:'member'}, status:{type:String,enum:['active','inactive','pending'],default:'pending'}, memberId:{type:Schema.Types.ObjectId,ref:'Member',default:null}, pd:{type:Object,default:null} },{timestamps:true});
const MemberSchema = new Schema({ memberCode:String, name:{type:String,required:true}, phone:{type:String,default:''}, nid:{type:String,default:''}, joined:String, target:{type:Number,default:100000}, status:{type:String,default:'active'} },{timestamps:true});
const ContributionSchema = new Schema({ memberId:{type:Schema.Types.ObjectId,required:true}, amount:{type:Number,required:true}, month:String, year:Number, type:{type:String,default:'Monthly Savings'}, date:String, notes:{type:String,default:''}, recordedBy:String },{timestamps:true});
const LoanSchema = new Schema({ memberId:{type:Schema.Types.ObjectId,required:true}, amount:{type:Number,required:true}, interest:{type:Number,default:10}, date:String, due:String, purpose:{type:String,default:''}, paid:{type:Number,default:0}, status:{type:String,default:'active'}, repayments:[{amount:Number,date:String,_id:false}] },{timestamps:true});
const LoanRequestSchema = new Schema({ memberId:{type:Schema.Types.ObjectId,required:true}, amount:{type:Number,required:true}, purpose:{type:String,required:true}, period:{type:Number,default:6}, notes:{type:String,default:''}, requestedDate:String, status:{type:String,enum:['pending','approved','rejected'],default:'pending'}, adminNote:{type:String,default:''}, processedDate:{type:String,default:null}, loanId:{type:Schema.Types.ObjectId,default:null}, _notified:{type:Boolean,default:false} },{timestamps:true});
const SettingsSchema = new Schema({ name:String, monthly:Number, interest:Number, _ts:{type:Number,default:0} });

// ── MODELS ───────────────────────────────────────────────────────
const User         = mongoose.models.User         || mongoose.model('User',UserSchema);
const Member       = mongoose.models.Member       || mongoose.model('Member',MemberSchema);
const Contribution = mongoose.models.Contribution || mongoose.model('Contribution',ContributionSchema);
const Loan         = mongoose.models.Loan         || mongoose.model('Loan',LoanSchema);
const LoanRequest  = mongoose.models.LoanRequest  || mongoose.model('LoanRequest',LoanRequestSchema);
const AppSettings  = mongoose.models.AppSettings  || mongoose.model('AppSettings',SettingsSchema);

const touch = () => AppSettings.updateOne({},{ $set:{_ts:Date.now()} });

async function bootstrap() {
  await connectDB();
  if (!await User.findOne({username:'admin'})) {
    await User.create({username:'admin',password:await bcrypt.hash('admin123',12),role:'admin',status:'active'});
  }
  if (!await AppSettings.findOne()) {
    await AppSettings.create({name:'Green Moon Savings Group',monthly:100000,interest:10,_ts:Date.now()});
  }
}

// ── AUTH MIDDLEWARE ───────────────────────────────────────────────
const authMW = (req,res,next) => {
  const t = req.headers.authorization?.split(' ')[1];
  if (!t) return res.status(401).json({error:'Unauthorized'});
  try { req.u = jwt.verify(t,JWT_SECRET); next(); } catch { res.status(401).json({error:'Invalid or expired token'}); }
};
const adminMW = (req,res,next) => req.u?.role==='admin' ? next() : res.status(403).json({error:'Admin only'});

// ── LOGIN ────────────────────────────────────────────────────────
app.post('/api/auth/login', async (req,res) => {
  try {
    await bootstrap();
    const {username,password} = req.body||{};
    if (!username||!password) return res.status(400).json({error:'Username and password required'});
    let user = await User.findOne({username:username.trim()}).lean();
    if (!user) {
      const mem = await Member.findOne({memberCode:username.trim()}).lean();
      if (mem) user = await User.findOne({memberId:mem._id}).lean();
    }
    if (!user) return res.status(401).json({error:'Invalid username or password'});
    if (!await bcrypt.compare(password,user.password)) return res.status(401).json({error:'Invalid username or password'});
    if (user.status==='pending')  return res.status(403).json({error:'Account pending approval'});
    if (user.status==='inactive') return res.status(403).json({error:'Account has been deactivated'});
    const token = jwt.sign({id:String(user._id),username:user.username,role:user.role,memberId:user.memberId?String(user.memberId):null},JWT_SECRET,{expiresIn:'30d'});
    res.json({token,user:{id:String(user._id),username:user.username,role:user.role,memberId:user.memberId?String(user.memberId):null}});
  } catch(e){console.error(e);res.status(500).json({error:'Server error'});}
});

// ── REGISTER ─────────────────────────────────────────────────────
app.post('/api/auth/register', async (req,res) => {
  try {
    await connectDB();
    const {username,password,name,phone,nid} = req.body||{};
    if (!username||!password||!name) return res.status(400).json({error:'Missing required fields'});
    if (password.length<6) return res.status(400).json({error:'Password must be at least 6 characters'});
    if (await User.findOne({username:username.trim()})) return res.status(400).json({error:'Username already taken'});
    await User.create({username:username.trim(),password:await bcrypt.hash(password,12),role:'member',status:'pending',pd:{name,phone,nid,reg:today()}});
    await touch();
    res.json({ok:true});
  } catch(e){res.status(500).json({error:'Server error'});}
});

// ── CHANGE PASSWORD ───────────────────────────────────────────────
app.put('/api/auth/password', authMW, async (req,res) => {
  try {
    await connectDB();
    const {oldPassword,newPassword} = req.body||{};
    if (!oldPassword||!newPassword||newPassword.length<6) return res.status(400).json({error:'Invalid data'});
    const user = await User.findById(req.u.id);
    if (!user||!await bcrypt.compare(oldPassword,user.password)) return res.status(400).json({error:'Current password is incorrect'});
    user.password = await bcrypt.hash(newPassword,12);
    await user.save();
    res.json({ok:true});
  } catch(e){res.status(500).json({error:'Server error'});}
});

// ── DATA SYNC ────────────────────────────────────────────────────
app.get('/api/data', authMW, async (req,res) => {
  try {
    await connectDB();
    const isAdmin = req.u.role==='admin';
    const mId = req.u.memberId;
    const [settings,members,contributions,loans,loanRequests,pendingUsers] = await Promise.all([
      AppSettings.findOne().lean(),
      Member.find().sort({createdAt:1}).lean(),
      Contribution.find().sort({date:-1}).lean(),
      Loan.find().sort({date:-1}).lean(),
      LoanRequest.find().sort({requestedDate:-1}).lean(),
      isAdmin ? User.find({status:'pending'},'-password').sort({createdAt:1}).lean() : Promise.resolve([]),
    ]);
    res.json({
      settings,
      members:      isAdmin ? members      : members.filter(m=>String(m._id)===mId),
      contributions: isAdmin ? contributions : contributions.filter(c=>String(c.memberId)===mId),
      loans:         isAdmin ? loans         : loans.filter(l=>String(l.memberId)===mId),
      loanRequests:  isAdmin ? loanRequests  : loanRequests.filter(r=>String(r.memberId)===mId),
      pendingUsers,
      _ts: settings?._ts||0,
    });
  } catch(e){console.error(e);res.status(500).json({error:'Server error'});}
});

// ── MEMBERS ──────────────────────────────────────────────────────
app.post('/api/members', authMW, adminMW, async (req,res) => {
  try {
    await connectDB();
    const {firstName,lastName,phone,nid,joined,target,username,password} = req.body||{};
    if (!firstName||!lastName||!username||!password) return res.status(400).json({error:'Missing fields'});
    if (await User.findOne({username:username.trim()})) return res.status(400).json({error:'Username taken'});
    const count = await Member.countDocuments();
    const memberCode = 'MBR'+String(count+1).padStart(3,'0');
    const member = await Member.create({memberCode,name:`${firstName.trim()} ${lastName.trim()}`,phone:phone||'',nid:nid||'',joined:joined||today(),target:Number(target)||100000,status:'active'});
    await User.create({username:username.trim(),password:await bcrypt.hash(password,12),role:'member',status:'active',memberId:member._id});
    await touch(); res.json(member);
  } catch(e){res.status(500).json({error:'Server error'});}
});

app.put('/api/members/:id', authMW, adminMW, async (req,res) => {
  try {
    await connectDB();
    const {firstName,lastName,phone,nid,joined,target,status} = req.body||{};
    const upd={};
    if (firstName&&lastName) upd.name=`${firstName.trim()} ${lastName.trim()}`;
    if (phone!==undefined)   upd.phone=phone;
    if (nid!==undefined)     upd.nid=nid;
    if (joined!==undefined)  upd.joined=joined;
    if (target!==undefined)  upd.target=Number(target);
    if (status!==undefined)  upd.status=status;
    const m = await Member.findByIdAndUpdate(req.params.id,{$set:upd},{new:true}).lean();
    if (!m) return res.status(404).json({error:'Member not found'});
    await touch(); res.json(m);
  } catch(e){res.status(500).json({error:'Server error'});}
});

// ── CONTRIBUTIONS ─────────────────────────────────────────────────
app.post('/api/contributions', authMW, adminMW, async (req,res) => {
  try {
    await connectDB();
    const {memberId,amount,month,year,type,date,notes} = req.body||{};
    if (!memberId||!amount) return res.status(400).json({error:'memberId and amount required'});
    const c = await Contribution.create({memberId,amount:Number(amount),month:month||'',year:Number(year)||new Date().getFullYear(),type:type||'Monthly Savings',date:date||today(),notes:notes||'',recordedBy:req.u.username});
    await touch(); res.json(c);
  } catch(e){res.status(500).json({error:'Server error'});}
});

// ── LOANS ─────────────────────────────────────────────────────────
app.post('/api/loans', authMW, adminMW, async (req,res) => {
  try {
    await connectDB();
    const {memberId,amount,interest,date,due,purpose} = req.body||{};
    if (!memberId||!amount) return res.status(400).json({error:'memberId and amount required'});
    const l = await Loan.create({memberId,amount:Number(amount),interest:Number(interest)||10,date:date||today(),due:due||'',purpose:purpose||'',paid:0,status:'active',repayments:[]});
    await touch(); res.json(l);
  } catch(e){res.status(500).json({error:'Server error'});}
});

app.post('/api/loans/:id/repay', authMW, adminMW, async (req,res) => {
  try {
    await connectDB();
    const {amount,date} = req.body||{};
    if (!amount||amount<=0) return res.status(400).json({error:'Invalid amount'});
    const loan = await Loan.findById(req.params.id);
    if (!loan) return res.status(404).json({error:'Loan not found'});
    const total = loan.amount*(1+loan.interest/100);
    loan.paid = Math.min(total,loan.paid+Number(amount));
    loan.repayments.push({amount:Number(amount),date:date||today()});
    if (loan.paid>=total) loan.status='paid';
    await loan.save(); await touch(); res.json(loan);
  } catch(e){res.status(500).json({error:'Server error'});}
});

// ── LOAN REQUESTS ─────────────────────────────────────────────────
app.post('/api/loan-requests', authMW, async (req,res) => {
  try {
    await connectDB();
    const mId = req.u.memberId;
    if (!mId) return res.status(400).json({error:'No member profile linked to account'});
    if (await LoanRequest.findOne({memberId:mId,status:'pending'})) return res.status(400).json({error:'You already have a pending request'});
    const {amount,purpose,period,notes} = req.body||{};
    if (!amount||!purpose) return res.status(400).json({error:'Amount and purpose required'});
    const lr = await LoanRequest.create({memberId:mId,amount:Number(amount),purpose,period:Number(period)||6,notes:notes||'',requestedDate:today(),status:'pending',_notified:false});
    await touch(); res.json(lr);
  } catch(e){res.status(500).json({error:'Server error'});}
});

app.put('/api/loan-requests/:id/approve', authMW, adminMW, async (req,res) => {
  try {
    await connectDB();
    const {amount,interest,date,due,adminNote} = req.body||{};
    const lr = await LoanRequest.findById(req.params.id);
    if (!lr||lr.status!=='pending') return res.status(404).json({error:'Not found or already processed'});
    const loan = await Loan.create({memberId:lr.memberId,amount:Number(amount),interest:Number(interest)||10,date:date||today(),due:due||'',purpose:lr.purpose,paid:0,status:'active',repayments:[]});
    lr.status='approved';lr.adminNote=adminNote||'';lr.processedDate=today();lr.loanId=loan._id;lr._notified=false;
    await lr.save(); await touch(); res.json({lr,loan});
  } catch(e){res.status(500).json({error:'Server error'});}
});

app.put('/api/loan-requests/:id/reject', authMW, adminMW, async (req,res) => {
  try {
    await connectDB();
    const {adminNote} = req.body||{};
    if (!adminNote) return res.status(400).json({error:'Rejection reason required'});
    const lr = await LoanRequest.findById(req.params.id);
    if (!lr||lr.status!=='pending') return res.status(404).json({error:'Not found or already processed'});
    lr.status='rejected';lr.adminNote=adminNote;lr.processedDate=today();lr._notified=false;
    await lr.save(); await touch(); res.json(lr);
  } catch(e){res.status(500).json({error:'Server error'});}
});

// ── USER MANAGEMENT ───────────────────────────────────────────────
app.put('/api/users/:id/approve', authMW, adminMW, async (req,res) => {
  try {
    await connectDB();
    const user = await User.findById(req.params.id);
    if (!user||user.status!=='pending') return res.status(404).json({error:'Pending user not found'});
    const d=user.pd||{};
    const count = await Member.countDocuments();
    const mc = 'MBR'+String(count+1).padStart(3,'0');
    const member = await Member.create({memberCode:mc,name:d.name||user.username,phone:d.phone||'',nid:d.nid||'',joined:today(),target:100000,status:'active'});
    user.memberId=member._id;user.status='active';user.pd=null;
    await user.save(); await touch();
    res.json({user:{id:String(user._id),username:user.username,role:user.role,memberId:String(user.memberId)},member});
  } catch(e){res.status(500).json({error:'Server error'});}
});

app.delete('/api/users/:id', authMW, adminMW, async (req,res) => {
  try {
    await connectDB();
    await User.findByIdAndDelete(req.params.id);
    await touch(); res.json({ok:true});
  } catch(e){res.status(500).json({error:'Server error'});}
});

// ── SETTINGS ──────────────────────────────────────────────────────
app.get('/api/settings', authMW, async (req,res) => {
  await connectDB();
  res.json(await AppSettings.findOne().lean());
});
app.put('/api/settings', authMW, adminMW, async (req,res) => {
  try {
    await connectDB();
    const {name,monthly,interest} = req.body||{};
    const s = await AppSettings.findOneAndUpdate({},{$set:{name:name||'Green Moon Savings Group',monthly:Number(monthly)||100000,interest:Number(interest)||10,_ts:Date.now()}},{new:true,upsert:true});
    res.json(s);
  } catch(e){res.status(500).json({error:'Server error'});}
});

app.get('/api/health',(req,res)=>res.json({ok:true,ts:Date.now()}));
app.use('/api/*',(req,res)=>res.status(404).json({error:'Not found'}));

module.exports = app;
